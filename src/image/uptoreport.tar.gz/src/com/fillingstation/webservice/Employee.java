package com.fillingstation.webservice;

import java.text.ParseException;
import java.util.ArrayList;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;

import com.fillingstation.json.EmployeeAttendanceJSON;
import com.fillingstation.json.EmployeeGetDetails;
import com.fillingstation.json.EmployeeReportAndCount;
import com.fillingstation.json.EmployeeReportJSON;
import com.fillingstation.logic.EmployeeLogic;
import com.fillingstation.logic.EmployeeReportLogic;


@Path(value="/employee")

public class Employee {

/*
 * API for registering and adding new employee	
 */
	    @POST
	    @Produces(value="application/json" )
	    @Path(value="/addemployee")
	    @Consumes(value="application/json")
	 
	 public Response addemployee(EmployeeGetDetails details) throws ParseException {
	    	System.out.println("going to add employee.......");
	    	EmployeeLogic.AddEmployee(details);
	    	System.out.println("added employee successfully.......");
	     	return Response.status(200).entity("SUCCESS").build();
}
	    /*
	     * API for updating the employee details
	     */
	    
	    @POST
	    @Produces(value="application/json" )
	    @Path(value="/updateemployee")
	    @Consumes(value="application/json")
	 
	 public Response updateemployee(EmployeeGetDetails details) throws ParseException {
	    	System.out.println("going to update employee.......");
	    	EmployeeLogic.UpdateEmployee(details);
	    	System.out.println("updated employee successfully.......");
	     	return Response.status(200).entity("SUCCESS").build();
}
	    /*
	     * API for deleting employee
	     */

	    @POST
	    @Produces(value="application/json" )
	    @Path(value="/deleteemployee")
	    @Consumes(value="application/json")
	 
	 public Response deleteemployee(EmployeeGetDetails details) throws ParseException {
	    	System.out.println("going to delete employee.......");
	    	EmployeeLogic.DeleteEmployee(details);
	    	System.out.println("deleted employee successfully.......");
	     	return Response.status(200).entity("SUCCESS").build();
}
	    /*
	     * API for checkin process
	     */
	    
	    @POST
	    @Produces(value="application/json" )
	    @Path(value="/employeecheckin")
	    @Consumes(value="application/json")
	 
	 public Response employeecheckin(EmployeeAttendanceJSON details) throws ParseException {
	    	System.out.println("going to add employee checkin details.......");
	    	EmployeeLogic.EmployeeCheckin(details);
	    	System.out.println("added employee checkin details successfully.......");
	     	return Response.status(200).entity("SUCCESS").build();
}
	    /*
	     * API for checkout process
	     */
	    
	    @POST
	    @Produces(value="application/json" )
	    @Path(value="/employeecheckout")
	    @Consumes(value="application/json")
	 
	 public Response employeecheckout(EmployeeAttendanceJSON details) throws ParseException {
	    	System.out.println("going to update employee checkout details.......");
	    	EmployeeLogic.EmployeeCheckout(details);
	    	System.out.println("updated employee check details successfully.......");
	     	return Response.status(200).entity("SUCCESS").build();
}
	    
	    /*
	     * API for employee maintenance report
	     */
	    
	    @POST
	    @Produces(value="application/json" )
	    @Path(value="/employeemaintenance")
	    @Consumes(value="application/json")
	 
	 public Response employeemaintenance() throws ParseException {
	    	System.out.println("going to generate employee maintenance report details.......");
	    	ArrayList<EmployeeReportJSON> employeeRetrievelist = new ArrayList<EmployeeReportJSON>();
	    	ArrayList<EmployeeReportJSON> employeeCountRetrievelist = new ArrayList<EmployeeReportJSON>();
	    	employeeRetrievelist=EmployeeReportLogic.EmployeeMaintenanceReport();
	    	employeeCountRetrievelist=EmployeeReportLogic.EmployeeMaintenanceCount();
	    	EmployeeReportAndCount ds = new EmployeeReportAndCount();
	    	 ds.setEmployeeRetrievelist(employeeRetrievelist);
	    	 ds.setEmployeeCountRetrievelist(employeeCountRetrievelist);
	    	System.out.println("generated employee maintenance report details successfully.......");
	     	return Response.status(200).entity(ds).build();
}
	    /*
	     * API for employee daily attendance report
	     */
	    
	    @POST
	    @Produces(value="application/json" )
	    @Path(value="/employeedailyreport")
	    @Consumes(value="application/json")
	    public Response employeedailyreport(EmployeeGetDetails details) throws ParseException {
	    	System.out.println("going to generate employee daily report details.......");
	    	ArrayList<EmployeeReportJSON> employeeRetrievelist = new ArrayList<EmployeeReportJSON>();
	    	ArrayList<EmployeeReportJSON> employeeCountRetrievelist = new ArrayList<EmployeeReportJSON>();
	    	employeeRetrievelist=EmployeeReportLogic.EmployeeDailyReport(details);
	    	employeeCountRetrievelist=EmployeeReportLogic.EmployeeDailyReportCount(details);
	    	EmployeeReportAndCount ds = new EmployeeReportAndCount();
	    	 ds.setEmployeeRetrievelist(employeeRetrievelist);
	    	 ds.setEmployeeCountRetrievelist(employeeCountRetrievelist);
	    	System.out.println("generated employee daily report details successfully.......");
	     	return Response.status(200).entity(ds).build();
}
	    
	    /*
	     * API for employee period attendance report
	     */
	    
	    @POST
	    @Produces(value="application/json" )
	    @Path(value="/employeeperiodreport")
	    @Consumes(value="application/json")
	    public Response employeeperiodreport(EmployeeGetDetails details) throws ParseException {
	    	System.out.println("going to generate employee daily report details.......");
	    	EmployeeReportLogic.EmployeePeriodReport(details);
	    	System.out.println("generated employee period report details successfully.......");
	     	return Response.status(200).entity("SUCCESS").build();
}
}