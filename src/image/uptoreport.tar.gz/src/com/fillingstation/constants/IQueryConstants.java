package com.fillingstation.constants;

public interface IQueryConstants {

	String EMP_INSERT="INSERT INTO EmployeeTable(FirstName,LastName,DOB,EmailId,MobileNo,"
			+ "Address,Type,Role,Department,EmployeeProofType,"
			+ "EmployeeProofNum,EmployeeId)VALUES(?,?,?,?,?,?,?,?,?,?,?,?) ";
String EMP_DELETE="DELETE FROM EmployeeTable WHERE EmployeeId = ? ";
String EMP_UPDATE="UPDATE EmployeeTable SET EmployeeId = ? ,FirstName = ?,"
					+ "LastName = ?,DOB = ?,EmailId = ?,MobileNo = ? ,"
					+ "Address = ?,Type = ?,Role = ?,Department = ?,"
					+ "EmployeeProofType = ?,EmployeeProofNum =? WHERE EmployeeId = ? ";
String EMP_CHECKIN="INSERT INTO EmployeeAttendanceTable(EmployeeId,Name,CheckinTime,Date,Type,Department)VALUES(?,?,?,?,?,?)";
String EMP_CHECKINDETAILS="SELECT FirstName,LastName,Role,Type,Department from EmployeeTable WHERE EmployeeId = ? ";
String EMP_CHECKOUTDETAILS="SELECT Role FROM EmployeeTable WHERE EmployeeId = ? ";
//String EMP_CHECKOUTDETAILS="SELECT CheckinTime FROM EmployeeAttendanceTable WHERE EmployeeId = ? AND Date = ? ";
String EMP_CHECKOUTUPDATE="UPDATE EmployeeAttendanceTable SET CheckoutTime = ?"
		+ " WHERE EmployeeId = ? and Date = ? ";
String EMPMAINTENANCE_REPORT="SELECT EmployeeId,FirstName,LastName,Type,Department from EmployeeTable";
String EMP_MAINTENANCE_COUNT="SELECT (SELECT COUNT(EmployeeId) FROM EmployeeTable WHERE Type = ? )as PermanentEmployeeCount,"
		+ "(SELECT COUNT(EmployeeId) FROM EmployeeTable WHERE Type = ? )as TemporaryEmployeeCount,"
		+ "COUNT(EmployeeId) as ContractEmployeeCount FROM EmployeeTable WHERE Type = ? ";
String EMP_DAILYREPORT="SELECT EmployeeId,Name,CheckinTime,CheckoutTime,TotalWorkHour,"
		+ "Type,Department FROM EmployeeAttendanceTable WHERE Date = ? ";
String EMP_DAILYREPORTCOUNT="SELECT (SELECT COUNT(EmployeeId) FROM EmployeeAttendanceTable WHERE Type = ? )as PermanentEmployeeCount," 
		+ "(SELECT COUNT(EmployeeId) FROM EmployeeAttendanceTable WHERE Type = ? )as TemporaryEmployeeCount,"
		+ "COUNT(EmployeeId) as ContractEmployeeCount FROM EmployeeAttendanceTable WHERE Type = ? AND Date = ? ";
}

