package com.fillingstation.json;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_DEFAULT)
public class EmployeeReportJSON {

	String firstName;
	String lastName;
	String employeeId;
	String department;
	String employeeType;
	int noOfPermanentEmployee;
	int noOfTemporaryEmployee;
	int noOfContractEmployee;
	String name;
	String checkinTime;
	String checkoutTime;
	String totalWorkHour;
	int todayPermanentCount = 0;
	int todayTemporaryCount = 0;
	int todaycontractCount = 0;
	int totalPermanentCount = 0;
	int totalTemporaryCount = 0;
	int totalContractCount = 0;
	int permanentCount;
	int temporaryCount;
	int contractCount;
	int permanentCountAbsent;
	int temporaryCountAbsent;
	int contractCountAbsent;
	
	
	public int getTodayPermanentCount() {
		return todayPermanentCount;
	}
	public void setTodayPermanentCount(int todayPermanentCount) {
		this.todayPermanentCount = todayPermanentCount;
	}
	public int getTodayTemporaryCount() {
		return todayTemporaryCount;
	}
	public void setTodayTemporaryCount(int todayTemporaryCount) {
		this.todayTemporaryCount = todayTemporaryCount;
	}
	public int getTodaycontractCount() {
		return todaycontractCount;
	}
	public void setTodaycontractCount(int todaycontractCount) {
		this.todaycontractCount = todaycontractCount;
	}
	public int getTotalPermanentCount() {
		return totalPermanentCount;
	}
	public void setTotalPermanentCount(int totalPermanentCount) {
		this.totalPermanentCount = totalPermanentCount;
	}
	public int getTotalTemporaryCount() {
		return totalTemporaryCount;
	}
	public void setTotalTemporaryCount(int totalTemporaryCount) {
		this.totalTemporaryCount = totalTemporaryCount;
	}
	public int getTotalContractCount() {
		return totalContractCount;
	}
	public void setTotalContractCount(int totalContractCount) {
		this.totalContractCount = totalContractCount;
	}
	public int getPermanentCount() {
		return permanentCount;
	}
	public void setPermanentCount(int permanentCount) {
		this.permanentCount = permanentCount;
	}
	public int getTemporaryCount() {
		return temporaryCount;
	}
	public void setTemporaryCount(int temporaryCount) {
		this.temporaryCount = temporaryCount;
	}
	public int getContractCount() {
		return contractCount;
	}
	public void setContractCount(int contractCount) {
		this.contractCount = contractCount;
	}
	public int getPermanentCountAbsent() {
		return permanentCountAbsent;
	}
	public void setPermanentCountAbsent(int permanentCountAbsent) {
		this.permanentCountAbsent = permanentCountAbsent;
	}
	public int getTemporaryCountAbsent() {
		return temporaryCountAbsent;
	}
	public void setTemporaryCountAbsent(int temporaryCountAbsent) {
		this.temporaryCountAbsent = temporaryCountAbsent;
	}
	public int getContractCountAbsent() {
		return contractCountAbsent;
	}
	public void setContractCountAbsent(int contractCountAbsent) {
		this.contractCountAbsent = contractCountAbsent;
	}
	public String getCheckinTime() {
		return checkinTime;
	}
	public void setCheckinTime(String checkinTime) {
		this.checkinTime = checkinTime;
	}
	public String getCheckoutTime() {
		return checkoutTime;
	}
	public void setCheckoutTime(String checkoutTime) {
		this.checkoutTime = checkoutTime;
	}
	public String getTotalWorkHour() {
		return totalWorkHour;
	}
	public void setTotalWorkHour(String totalWorkHour) {
		this.totalWorkHour = totalWorkHour;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getNoOfPermanentEmployee() {
		return noOfPermanentEmployee;
	}
	public void setNoOfPermanentEmployee(int noOfPermanentEmployee) {
		this.noOfPermanentEmployee = noOfPermanentEmployee;
	}
	public int getNoOfTemporaryEmployee() {
		return noOfTemporaryEmployee;
	}
	public void setNoOfTemporaryEmployee(int noOfTemporaryEmployee) {
		this.noOfTemporaryEmployee = noOfTemporaryEmployee;
	}
	public int getNoOfContractEmployee() {
		return noOfContractEmployee;
	}
	public void setNoOfContractEmployee(int noOfContractEmployee) {
		this.noOfContractEmployee = noOfContractEmployee;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public String getEmployeeType() {
		return employeeType;
	}
	public void setEmployeeType(String employeeType) {
		this.employeeType = employeeType;
	}
	
	
}
