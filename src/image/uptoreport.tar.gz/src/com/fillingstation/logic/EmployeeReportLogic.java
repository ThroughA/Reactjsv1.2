package com.fillingstation.logic;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.fillingstation.constants.IQueryConstants;
import com.fillingstation.json.EmployeeGetDetails;
import com.fillingstation.json.EmployeeReportJSON;
import com.fillingstation.util.DBUtil;

public class EmployeeReportLogic {

	/*
	 * function for generating employee maintenance report
	 */
	
	public static ArrayList<EmployeeReportJSON> EmployeeMaintenanceReport() {
		
			ArrayList<EmployeeReportJSON> employeeRetrievelist = new ArrayList<EmployeeReportJSON>();
			Connection connection=null;
			try {
				connection =DBUtil.getDBConnection();
				
				String querySelect=IQueryConstants.EMPMAINTENANCE_REPORT;
				PreparedStatement preparedStmt = connection.prepareStatement(querySelect);
		        ResultSet rs=preparedStmt.executeQuery();
		        while(rs.next())
		        {
		        	EmployeeReportJSON employeeRetrieveobj = new EmployeeReportJSON();
		        	employeeRetrieveobj.setEmployeeId(rs.getString("EmployeeId"));
		        	employeeRetrieveobj.setFirstName(rs.getString("FirstName"));
		        	employeeRetrieveobj.setLastName(rs.getString("LastName"));
		        	employeeRetrieveobj.setEmployeeType(rs.getString("Type"));
		        	employeeRetrieveobj.setDepartment(rs.getString("Department"));
		        	employeeRetrievelist.add(employeeRetrieveobj);
		        }
		        connection.close();  
		        } catch (SQLException e)
		        {
		        e.printStackTrace();
		        }
		         	
			   finally {
				DBUtil.closeConnection(connection);
			}
		        
			   return employeeRetrievelist;
			
	    }
	
	public static ArrayList<EmployeeReportJSON> EmployeeMaintenanceCount() {
		
		ArrayList<EmployeeReportJSON> employeeCountRetrievelist = new ArrayList<EmployeeReportJSON>();
		Connection connection=null;
		try {
			connection =DBUtil.getDBConnection();
			
			
	        String querySelect=IQueryConstants.EMP_MAINTENANCE_COUNT;
			PreparedStatement preparedStmt= connection.prepareStatement(querySelect);
			preparedStmt.setString(1,"permanent");
			preparedStmt.setString(2,"temporary");
			preparedStmt.setString(3,"contract");
	        ResultSet rs=preparedStmt.executeQuery();
	        while(rs.next())
	        {
	        EmployeeReportJSON employeeRetrieveobj = new EmployeeReportJSON();
	        employeeRetrieveobj.setNoOfPermanentEmployee(rs.getInt("PermanentEmployeeCount"));
        	employeeRetrieveobj.setNoOfTemporaryEmployee(rs.getInt("TemporaryEmployeeCount"));
        	employeeRetrieveobj.setNoOfContractEmployee(rs.getInt("ContractEmployeeCount"));
        	employeeCountRetrievelist.add(employeeRetrieveobj);
	        }
	        connection.close();  
	        } catch (SQLException e)
	        {
	        e.printStackTrace();
	        }
	         	
		   finally {
			DBUtil.closeConnection(connection);
		}
	        
		   return employeeCountRetrievelist;
		
    }


	/*
	 * function for generating employee daily attendance report
	 */
	
	public static ArrayList<EmployeeReportJSON> EmployeeDailyReport(EmployeeGetDetails details) {
		
		ArrayList<EmployeeReportJSON> employeeRetrievelist = new ArrayList<EmployeeReportJSON>();
		Connection connection=null;
		try {
			connection =DBUtil.getDBConnection();
			
			String querySelect=IQueryConstants.EMP_DAILYREPORT;
			PreparedStatement preparedStmt = connection.prepareStatement(querySelect);
			preparedStmt.setString(1,details.getDate());
			ResultSet rs=preparedStmt.executeQuery();
	        while(rs.next())
	        {
	        	EmployeeReportJSON employeeRetrieveobj = new EmployeeReportJSON();
	        	employeeRetrieveobj.setEmployeeId(rs.getString("EmployeeId"));
	        	employeeRetrieveobj.setName(rs.getString("Name"));
	        	employeeRetrieveobj.setCheckinTime(rs.getString("CheckinTime"));
	        	employeeRetrieveobj.setCheckoutTime(rs.getString("CheckoutTime"));
	        	employeeRetrieveobj.setTotalWorkHour(rs.getString("TotalWorkHour"));
	        	employeeRetrieveobj.setEmployeeType(rs.getString("Type"));
	        	employeeRetrieveobj.setDepartment(rs.getString("Department"));
	        	employeeRetrievelist.add(employeeRetrieveobj);
	        }
	        connection.close();  
	        } catch (SQLException e)
	        {
	        e.printStackTrace();
	        }
	         	
		   finally {
			DBUtil.closeConnection(connection);
		}
	        
		   return employeeRetrievelist;
		
    }
	
public static ArrayList<EmployeeReportJSON> EmployeeDailyReportCount(EmployeeGetDetails details) {
		
	int todayPermanentCount = 0;
	int todayTemporaryCount = 0;
	int todaycontractCount = 0;
	int totalPermanentCount = 0;
	int totalTemporaryCount = 0;
	int totalContractCount = 0;
	int permanentCount;
	int temporaryCount;
	int contractCount;
	int permanentCountAbsent;
	int temporaryCountAbsent;
	int contractCountAbsent;
	
		ArrayList<EmployeeReportJSON> employeeCountRetrievelist = new ArrayList<EmployeeReportJSON>();
		Connection connection=null;
		try {
			connection =DBUtil.getDBConnection();
			
			String querySelect=IQueryConstants.EMP_DAILYREPORTCOUNT;
			PreparedStatement preparedStmt = connection.prepareStatement(querySelect);
			preparedStmt.setString(1,"permanent");
			preparedStmt.setString(2,"temporary");
			preparedStmt.setString(3,"contract");
			preparedStmt.setString(4,details.getDate());
	        ResultSet rs=preparedStmt.executeQuery();
	        while(rs.next())
	        { 
	        	todayPermanentCount=rs.getInt("PermanentEmployeeCount");
	        	todayTemporaryCount=rs.getInt("TemporaryEmployeeCount");
	        	todaycontractCount=rs.getInt("ContractEmployeeCount");
	        	EmployeeReportJSON employeeRetrieveobj = new EmployeeReportJSON();
		        employeeRetrieveobj.setTodayPermanentCount(todayPermanentCount);
	        	employeeRetrieveobj.setTodayTemporaryCount(todayTemporaryCount);
	        	employeeRetrieveobj.setTodaycontractCount(todaycontractCount);
	        	employeeCountRetrievelist.add(employeeRetrieveobj);
	        }
	        
	        String querySelect1=IQueryConstants.EMP_MAINTENANCE_COUNT;
			PreparedStatement preparedStmt1= connection.prepareStatement(querySelect1);
			preparedStmt1.setString(1,"permanent");
			preparedStmt1.setString(2,"temporary");
			preparedStmt1.setString(3,"contract");
	        ResultSet rs1=preparedStmt1.executeQuery();
	        while(rs1.next())
	        {
	        	 totalPermanentCount=rs.getInt("PermanentEmployeeCount");
	 	        totalTemporaryCount=rs.getInt("TemporaryEmployeeCount");
	 	        totalContractCount=rs.getInt("ContractEmployeeCount");
	 	       EmployeeReportJSON employeeRetrieveobj = new EmployeeReportJSON();
		        employeeRetrieveobj.setTotalPermanentCount(totalPermanentCount);
	        	employeeRetrieveobj.setTotalTemporaryCount(totalTemporaryCount);
	        	employeeRetrieveobj.setTotalContractCount(totalContractCount);
	        	employeeCountRetrievelist.add(employeeRetrieveobj);
	      
	        }
	        connection.close(); 
	        
	        permanentCountAbsent=totalPermanentCount-todayPermanentCount;
	    	temporaryCountAbsent=totalTemporaryCount-todayTemporaryCount;
	    	contractCountAbsent=totalContractCount-todaycontractCount;
	      
	    	EmployeeReportJSON employeeRetrieveobj = new EmployeeReportJSON();
	        employeeRetrieveobj.setNoOfPermanentEmployee(permanentCountAbsent);
        	employeeRetrieveobj.setNoOfTemporaryEmployee(temporaryCountAbsent);
        	employeeRetrieveobj.setNoOfContractEmployee(contractCountAbsent);
        	
        	employeeCountRetrievelist.add(employeeRetrieveobj);
	        /*EmployeeReportJSON employeeRetrieveobj = new EmployeeReportJSON();
	        employeeRetrieveobj.setNoOfPermanentEmployee(rs.getInt("PermanentEmployeeCount"));
        	employeeRetrieveobj.setNoOfTemporaryEmployee(rs.getInt("TemporaryEmployeeCount"));
        	employeeRetrieveobj.setNoOfContractEmployee(rs.getInt("ContractEmployeeCount"));
        	employeeCountRetrievelist.add(employeeRetrieveobj);
        	*/
	        } catch (SQLException e)
	        {
	        e.printStackTrace();
	        }
	         	
		   finally {
			DBUtil.closeConnection(connection);
		}
	        
		   return employeeCountRetrievelist;
		
    }

	/*
	 * function for generating employee period attendance report
	 */
	
	public static void EmployeePeriodReport(EmployeeGetDetails details) {
	
		
	}

}
