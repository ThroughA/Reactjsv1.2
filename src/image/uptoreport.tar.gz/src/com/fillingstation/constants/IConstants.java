package com.fillingstation.constants;

public interface IConstants {


String DB_CONTEXT_LOOKUP_NAME = "java:jboss/datasources";
	
	String DB_LOOKUP_NAME = "MYSQLDS";
}
