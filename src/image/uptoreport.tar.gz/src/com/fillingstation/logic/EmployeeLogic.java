package com.fillingstation.logic;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.fillingstation.constants.IQueryConstants;
import com.fillingstation.json.EmployeeAttendanceJSON;
import com.fillingstation.json.EmployeeGetDetails;
import com.fillingstation.util.DBUtil;

public class EmployeeLogic {

	static String employeeRole=null;
	static String employeeId=null;
	static String employeeType=null;
	static String department=null;
	
	/*
	 * function to add new emplpoyee
	 */
	
	public static void AddEmployee(EmployeeGetDetails details) {
		Connection connection=null;
		try {
			
			System.out.println("got the employee details to be added............");
			connection =DBUtil.getDBConnection();
			String querySelect=IQueryConstants.EMP_INSERT;
			PreparedStatement preparedStmt = connection.prepareStatement(querySelect);
			    preparedStmt.setString(1, details.getFirstName());
				preparedStmt.setString(2,details.getLastName());
				preparedStmt.setString(3,details.getDob());
				preparedStmt.setString(4,details.getEmailId());
				preparedStmt.setLong(5,details.getMobileNo());
				preparedStmt.setString(6,details.getAddress());
			    preparedStmt.setString(7,details.getEmployeeType());
			    preparedStmt.setString(8,details.getRole());
			    preparedStmt.setString(9,details.getDepartment());
			    preparedStmt.setString(10,details.getEmployeeProofType());
			    preparedStmt.setString(11,details.getEmployeeProofNo());
			    preparedStmt.setString(12,details.getEmployeeId());
			    preparedStmt.executeUpdate();
			    System.out.println("completed adding employee returing to webservice............");
			    connection.close(); 		 
        } catch (SQLException e)
        {
        e.printStackTrace();
        }
         	
	   finally {
		DBUtil.closeConnection(connection);
	}
		
	}

	/*
	 * function to delete employee
	 */
	
	public static void DeleteEmployee(EmployeeGetDetails details) {
		
		Connection connection=null;
		try {
			
			System.out.println("got the employee details to be deleted............");
			connection =DBUtil.getDBConnection();
			String querySelect=IQueryConstants.EMP_DELETE;
			PreparedStatement preparedStmt = connection.prepareStatement(querySelect);
			    preparedStmt.setString(1, details.getEmployeeId());
			    preparedStmt.executeUpdate();
			    System.out.println("completed deleting remployee returing to webservice............");
			    connection.close(); 		 
        } catch (SQLException e)
        {
        e.printStackTrace();
        }
         	
	   finally {
		DBUtil.closeConnection(connection);
	}
		
	}
	
	/*
	 * function to update employee
	 */
	
public static void UpdateEmployee(EmployeeGetDetails details) {
		
		Connection connection=null;
		try {
			
			System.out.println("got the employee details to be updated............");
			connection =DBUtil.getDBConnection();
			String querySelect=IQueryConstants.EMP_UPDATE;
			PreparedStatement preparedStmt = connection.prepareStatement(querySelect);
			    preparedStmt.setString(1,details.getEmployeeId());
			    preparedStmt.setString(2,details.getFirstName());
				preparedStmt.setString(3,details.getLastName());
				preparedStmt.setString(4,details.getDob());
				preparedStmt.setString(5,details.getEmailId());
				preparedStmt.setLong(6,details.getMobileNo());
				preparedStmt.setString(7,details.getAddress());
			    preparedStmt.setString(8,details.getEmployeeType());
			    preparedStmt.setString(9,details.getRole());
			    preparedStmt.setString(10,details.getDepartment());
			    preparedStmt.setString(11,details.getEmployeeType());
			    preparedStmt.setString(12,details.getEmployeeProofNo());
			    preparedStmt.setString(13,details.getEmployeeId());
			    preparedStmt.executeUpdate();
			    System.out.println("completed updating employee returing to webservice............");
			    connection.close(); 		 
        } catch (SQLException e)
        {
        e.printStackTrace();
        }
         	
	   finally {
		DBUtil.closeConnection(connection);
	}
		
	}


/*
 * function to insert employee into DB 
 * on clicking the checkin button
 */
public static void EmployeeCheckin(EmployeeAttendanceJSON details) {
	
	Connection connection=null;
	String firstName = null;
	String lastName = null;
	String name = null;
	
	
	try {
		
		System.out.println("got the employee details for checkin from employeetable............");
		connection =DBUtil.getDBConnection();
		String querySelect=IQueryConstants.EMP_CHECKINDETAILS;
		PreparedStatement preparedStmt = connection.prepareStatement(querySelect);
		    preparedStmt.setString(1,details.getEmployeeId());
		    ResultSet rs=preparedStmt.executeQuery();
		    while(rs.next()) {
		    	firstName=rs.getString("FirstName");
		    	lastName=rs.getString("LastName");
		    	employeeRole=rs.getString("Role");
		    	employeeType=rs.getString("Type");
		    	department=rs.getString("Department");
		    }
		    name=firstName+" "+lastName;
		    System.out.println("employee role is...."+employeeRole);
		    int result=employeeRole.compareTo("general");
	    	System.out.println("compared result value...."+result);
		    if(result<=0) {
		    	employeeId=details.getEmployeeId()+"(G)";
		    }
		    else {
		    	employeeId=details.getEmployeeId()+"(S)";
		    }
		    System.out.println("got the employee details for checkin moving to inserting into DB............");   
		String querySelect1=IQueryConstants.EMP_CHECKIN;
		PreparedStatement preparedStmt1 = connection.prepareStatement(querySelect1);
		    preparedStmt1.setString(1,employeeId);
		    preparedStmt1.setString(2,name);
		    preparedStmt1.setString(3,details.getCheckinTime());
		    preparedStmt1.setString(4,details.getDate());
		    preparedStmt1.setString(5,employeeType);
		    preparedStmt1.setString(6,department);
		    
		    preparedStmt1.executeUpdate();
		    System.out.println("completed checkin returing to webservice............");
		    connection.close(); 
    } catch (SQLException e)
    {
    e.printStackTrace();
    }
     	
   finally {
	DBUtil.closeConnection(connection);
}
}

/*
 * function to calculate the total work hour on clicking the checkout button
 * after calculation checkouttime and totl work hour will be updated into DB
 */

public static void EmployeeCheckout(EmployeeAttendanceJSON details) throws ParseException {
	
	String totalWorkHour;
	  String checkinTime = null;
	  String checkoutTime = null;
	  long second = 1000l;
      long minute = 60l * second;
      long hour = 60l * minute;
      Date checkinTimecal;
      Date checkoutTimecal;
      long difference;
      long hh;
      long mm;
      long ss;
      
	Connection connection=null;
	try {
		System.out.println("getting the employee details for calculating total working hours............");
		connection =DBUtil.getDBConnection();
	/*	String querySelect=IQueryConstants.EMP_CHECKOUTDETAILS;
		PreparedStatement preparedStmt = connection.prepareStatement(querySelect);
		    preparedStmt.setString(1,details.getEmployeeId());
		    preparedStmt.setString(2,details.getDate());
		    ResultSet rs=preparedStmt.executeQuery();
		    while(rs.next()) {
		    	checkinTime=rs.getString("CheckinTime");
		    }
		    System.out.println("got the checkintime employee details for calculating checkout............"+checkinTime);
		    SimpleDateFormat format = new SimpleDateFormat("HH:mm:ss");
		    System.out.println("calculating totalworking hour............");
		    checkoutTime=details.getCheckoutTime();
		    System.out.println("checkout time............"+checkoutTime);
		    checkinTimecal=format.parse(checkinTime);
		    System.out.println("checkin time cal............"+checkinTimecal);
		    checkoutTimecal=format.parse(checkoutTime);
		    System.out.println("checkout time cal............"+checkoutTimecal);
			difference = checkoutTimecal.getTime() - checkinTimecal.getTime();
			System.out.println("difference in  time ............"+difference);
			hh=difference / hour;
			mm=(difference % hour) / minute ;
			ss=(difference % minute) / second;
			totalWorkHour=hh+":"+mm+":"+ss;
		    System.out.println("completed calculating  totalworkhour............"+totalWorkHour);
	    	System.out.println("got the employee details for checkout fully............");
		*/
		String querySelect=IQueryConstants.EMP_CHECKOUTDETAILS;
		PreparedStatement preparedStmt = connection.prepareStatement(querySelect);
		    preparedStmt.setString(1,details.getEmployeeId());
		    ResultSet rs=preparedStmt.executeQuery();
		    while(rs.next()) {
		    	employeeRole=rs.getString("Role");
		    }
		    int result=employeeRole.compareTo("general");
	    	System.out.println("compared result value...."+result);
		    if(result<=0) {
		    	employeeId=details.getEmployeeId()+"(G)";
		    }
		    else {
		    	employeeId=details.getEmployeeId()+"(S)";
		    }
		
		String querySelect1=IQueryConstants.EMP_CHECKOUTUPDATE;
		PreparedStatement preparedStmt1 = connection.prepareStatement(querySelect1);
		    preparedStmt1.setString(1,details.getCheckoutTime());
			//preparedStmt1.setString(2,totalWorkHour);
		    preparedStmt1.setString(2,employeeId);
		    preparedStmt1.setString(3,details.getDate());
		    preparedStmt1.executeUpdate();
		    System.out.println("completed checking out updation returing to webservice............");
		    connection.close(); 	 
    } catch (SQLException e)
    {
    e.printStackTrace();
    }
     	
   finally {
	DBUtil.closeConnection(connection);
}
}
}
