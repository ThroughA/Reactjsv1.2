package com.fillingstation.json;

import java.util.ArrayList;

public class EmployeeReportAndCount {

	private ArrayList<EmployeeReportJSON> employeeRetrievelist ;
	private ArrayList<EmployeeReportJSON> employeeCountRetrievelist;
	
	public ArrayList<EmployeeReportJSON> getEmployeeRetrievelist() {
		return employeeRetrievelist;
	}
	public void setEmployeeRetrievelist(ArrayList<EmployeeReportJSON> employeeRetrievelist) {
		this.employeeRetrievelist = employeeRetrievelist;
	}
	public ArrayList<EmployeeReportJSON> getEmployeeCountRetrievelist() {
		return employeeCountRetrievelist;
	}
	public void setEmployeeCountRetrievelist(ArrayList<EmployeeReportJSON> employeeCountRetrievelist) {
		this.employeeCountRetrievelist = employeeCountRetrievelist;
	}
	
	}
